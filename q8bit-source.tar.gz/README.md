Development moved to https://gitlab.com/blacknet-ninja

https://q8bit.org/ aims to continue on Q8BIT chain.
